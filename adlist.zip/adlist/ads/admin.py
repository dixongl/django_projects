from django.contrib import admin
from ads.models import Ad

# Register your models here.

admin.site.register(Ad)
